# OBJ Viewer - Qt 5.6.3 OpenGL ES 2.0

这是一个基于Qt 5.6.3和OpenGL ES 2.0的简单OBJ模型查看器，专为ARM嵌入式平台（Mali-400 GPU）设计。

## 环境要求

- Qt 5.6.3
- OpenGL ES 2.0
- ARM嵌入式平台，GPU为Mali-400
- qmake构建系统

## 功能特性

- ✅ 解析Wavefront OBJ文件（支持v、vt、vn、f指令）
- ✅ 使用VBO/IBO加载顶点数据
- ✅ 使用glDrawElements(GL_TRIANGLES)绘制
- ✅ OpenGL ES 2.0兼容的着色器（attribute/varying语法）
- ✅ 简单的Lambert漫反射光照
- ✅ 鼠标交互控制（旋转、缩放）
- ✅ 自动旋转动画

## 项目结构

```
objviewer/
├── objviewer.pro           # qmake项目文件
├── resources.qrc           # Qt资源文件
├── src/
│   ├── main.cpp           # 主程序入口
│   ├── objloader.h        # OBJ加载器头文件
│   ├── objloader.cpp      # OBJ加载器实现
│   ├── objviewerwidget.h  # OpenGL渲染Widget头文件
│   └── objviewerwidget.cpp # OpenGL渲染Widget实现
├── shaders/
│   ├── vertex.glsl        # 顶点着色器
│   └── fragment.glsl      # 片段着色器
└── models/
    └── cube.obj           # 测试用立方体模型
```

## 编译方法

1. 确保Qt 5.6.3开发环境已正确安装
2. 进入项目目录：
   ```bash
   cd objviewer
   ```
3. 生成Makefile：
   ```bash
   qmake objviewer.pro
   ```
4. 编译项目：
   ```bash
   make
   ```
5. 运行程序：
   ```bash
   ./bin/objviewer
   ```

## 使用说明

### 控制方式
- **左键拖拽**：旋转模型
- **鼠标滚轮**：缩放模型
- **自动旋转**：模型会绕Y轴自动旋转

### 加载模型
- 启动程序后会自动加载内置的立方体测试模型
- 使用菜单 "File > Open Model..." 加载自定义OBJ文件
- 支持标准的Wavefront OBJ格式

### 支持的OBJ特性
- `v x y z` - 顶点坐标
- `vt u v` - 纹理坐标
- `vn x y z` - 法向量
- `f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3` - 三角形面

## 技术实现

### OpenGL ES 2.0兼容性
- 使用attribute/varying变量（ES 2.0语法）
- precision修饰符用于片段着色器
- 兼容Mali-400 GPU的功能限制

### 渲染管线
1. **顶点缓冲区**：使用QOpenGLBuffer管理VBO/IBO
2. **着色器程序**：ES 2.0兼容的GLSL着色器
3. **绘制调用**：使用glDrawElements进行索引绘制
4. **光照计算**：简单的Lambert漫反射模型

### 内存管理
- 自动管理OpenGL资源的创建和销毁
- 使用Qt的智能指针和RAII模式
- 优化的顶点数据结构

## 故障排除

### 编译问题
- 确保已安装Qt 5.6.3开发包
- 检查OpenGL ES 2.0支持
- 验证qmake版本和路径

### 运行时问题
- 检查OpenGL ES 2.0驱动程序
- 验证Mali-400 GPU支持
- 查看调试输出信息

### 模型加载问题
- 确保OBJ文件格式正确
- 检查文件路径和权限
- 验证模型包含有效的几何数据

## 扩展功能

可以基于此框架添加更多功能：
- 纹理贴图支持
- 更复杂的光照模型
- 材质属性解析
- 多个模型渲染
- 骨骼动画支持

## 许可证

此项目仅供学习和参考使用。
