#include <QApplication>
#include <QMainWindow>
#include <QMenuBar>
#include <QFileDialog>
#include <QMessageBox>
#include <QVBoxLayout>
#include <QWidget>
#include "objviewerwidget.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr)
        : QMainWindow(parent)
        , m_viewer(new ObjViewerWidget(this))
    {
        setupUI();
        setupMenus();
        
        // 设置窗口属性
        setWindowTitle("OBJ Viewer - Qt 5.6.3 OpenGL ES 2.0");
        resize(800, 600);
        
        // 尝试加载默认模型
        loadDefaultModel();
    }

private slots:
    void openModel()
    {
        QString fileName = QFileDialog::getOpenFileName(
            this,
            "Open OBJ Model",
            "",
            "Wavefront OBJ (*.obj);;All Files (*)"
        );
        
        if (!fileName.isEmpty()) {
            if (m_viewer->loadModel(fileName)) {
                statusBar()->showMessage("Model loaded: " + fileName, 2000);
            } else {
                QMessageBox::warning(this, "Error", "Failed to load model: " + fileName);
            }
        }
    }
    
    void about()
    {
        QMessageBox::about(this, "About OBJ Viewer",
            "OBJ Viewer\n\n"
            "A simple Wavefront OBJ model viewer built with:\n"
            "- Qt 5.6.3\n"
            "- OpenGL ES 2.0\n"
            "- Compatible with ARM Mali-400 GPU\n\n"
            "Controls:\n"
            "- Left mouse drag: Rotate model\n"
            "- Mouse wheel: Zoom in/out\n"
            "- Model auto-rotates around Y axis");
    }

private:
    void setupUI()
    {
        setCentralWidget(m_viewer);
        statusBar()->showMessage("Ready");
    }
    
    void setupMenus()
    {
        QMenuBar *menuBar = this->menuBar();
        
        // File menu
        QMenu *fileMenu = menuBar->addMenu("&File");
        
        QAction *openAction = fileMenu->addAction("&Open Model...");
        openAction->setShortcut(QKeySequence::Open);
        connect(openAction, &QAction::triggered, this, &MainWindow::openModel);
        
        fileMenu->addSeparator();
        
        QAction *exitAction = fileMenu->addAction("E&xit");
        exitAction->setShortcut(QKeySequence::Quit);
        connect(exitAction, &QAction::triggered, this, &QWidget::close);
        
        // Help menu
        QMenu *helpMenu = menuBar->addMenu("&Help");
        
        QAction *aboutAction = helpMenu->addAction("&About");
        connect(aboutAction, &QAction::triggered, this, &MainWindow::about);
    }
    
    void loadDefaultModel()
    {
        // 尝试加载默认的测试模型
        QString defaultModel = ":/models/cube.obj";
        if (QFile::exists(defaultModel)) {
            m_viewer->loadModel(defaultModel);
            statusBar()->showMessage("Default model loaded", 2000);
        } else {
            statusBar()->showMessage("No default model - use File > Open to load a model");
        }
    }
    
private:
    ObjViewerWidget *m_viewer;
};

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // 设置OpenGL格式
    QSurfaceFormat format;
    format.setVersion(2, 0);
    format.setProfile(QSurfaceFormat::NoProfile);
    format.setRenderableType(QSurfaceFormat::OpenGLES);
    format.setDepthBufferSize(24);
    format.setStencilBufferSize(8);
    format.setSamples(4); // 4x MSAA
    QSurfaceFormat::setDefaultFormat(format);
    
    MainWindow window;
    window.show();
    
    return app.exec();
}
