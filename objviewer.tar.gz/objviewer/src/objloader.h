#ifndef OBJLOADER_H
#define OBJLOADER_H

#include <QVector>
#include <QVector3D>
#include <QVector2D>
#include <QString>

struct Vertex {
    QVector3D position;
    QVector2D texCoord;
    QVector3D normal;
};

class ObjLoader
{
public:
    ObjLoader();
    
    bool loadOBJ(const QString& filePath);
    
    const QVector<Vertex>& getVertices() const { return vertices; }
    const QVector<unsigned int>& getIndices() const { return indices; }
    
    void clear();
    
private:
    QVector<QVector3D> temp_vertices;
    QVector<QVector2D> temp_uvs;
    QVector<QVector3D> temp_normals;
    
    QVector<Vertex> vertices;
    QVector<unsigned int> indices;
    
    void parseFace(const QString& line);
    int findOrAddVertex(const QVector3D& vertex, const QVector2D& uv, const QVector3D& normal);
};

#endif // OBJLOADER_H
