#include "objloader.h"
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>

ObjLoader::ObjLoader()
{
}

bool ObjLoader::loadOBJ(const QString& filePath)
{
    clear();
    
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Cannot open file:" << filePath;
        return false;
    }
    
    QTextStream stream(&file);
    
    while (!stream.atEnd()) {
        QString line = stream.readLine().trimmed();
        
        if (line.isEmpty() || line.startsWith("#")) {
            continue;
        }
        
        QStringList parts = line.split(' ', QString::SkipEmptyParts);
        if (parts.isEmpty()) {
            continue;
        }
        
        if (parts[0] == "v" && parts.size() >= 4) {
            // 顶点坐标
            float x = parts[1].toFloat();
            float y = parts[2].toFloat();
            float z = parts[3].toFloat();
            temp_vertices.append(QVector3D(x, y, z));
        }
        else if (parts[0] == "vt" && parts.size() >= 3) {
            // 纹理坐标
            float u = parts[1].toFloat();
            float v = parts[2].toFloat();
            temp_uvs.append(QVector2D(u, v));
        }
        else if (parts[0] == "vn" && parts.size() >= 4) {
            // 法向量
            float x = parts[1].toFloat();
            float y = parts[2].toFloat();
            float z = parts[3].toFloat();
            temp_normals.append(QVector3D(x, y, z).normalized());
        }
        else if (parts[0] == "f") {
            // 面数据
            parseFace(line);
        }
    }
    
    file.close();
    
    qDebug() << "Loaded OBJ file:" << filePath;
    qDebug() << "Vertices:" << vertices.size();
    qDebug() << "Indices:" << indices.size();
    qDebug() << "Triangles:" << indices.size() / 3;
    
    return !vertices.isEmpty() && !indices.isEmpty();
}

void ObjLoader::parseFace(const QString& line)
{
    QStringList parts = line.split(' ', QString::SkipEmptyParts);
    if (parts.size() < 4) {
        return;
    }
    
    QVector<int> faceIndices;
    
    // 解析面的每个顶点
    for (int i = 1; i < parts.size(); ++i) {
        QString vertexStr = parts[i];
        QStringList vertexParts = vertexStr.split('/');
        
        if (vertexParts.isEmpty()) {
            continue;
        }
        
        // 获取顶点索引 (OBJ格式索引从1开始)
        int vertexIndex = vertexParts[0].toInt() - 1;
        int uvIndex = -1;
        int normalIndex = -1;
        
        if (vertexParts.size() > 1 && !vertexParts[1].isEmpty()) {
            uvIndex = vertexParts[1].toInt() - 1;
        }
        
        if (vertexParts.size() > 2 && !vertexParts[2].isEmpty()) {
            normalIndex = vertexParts[2].toInt() - 1;
        }
        
        // 检查索引有效性
        if (vertexIndex < 0 || vertexIndex >= temp_vertices.size()) {
            continue;
        }
        
        QVector3D vertex = temp_vertices[vertexIndex];
        QVector2D uv = (uvIndex >= 0 && uvIndex < temp_uvs.size()) ? temp_uvs[uvIndex] : QVector2D(0, 0);
        QVector3D normal = (normalIndex >= 0 && normalIndex < temp_normals.size()) ? temp_normals[normalIndex] : QVector3D(0, 0, 1);
        
        int index = findOrAddVertex(vertex, uv, normal);
        faceIndices.append(index);
    }
    
    // 将面三角化 (对于有超过3个顶点的面)
    if (faceIndices.size() >= 3) {
        for (int i = 1; i < faceIndices.size() - 1; ++i) {
            indices.append(faceIndices[0]);
            indices.append(faceIndices[i]);
            indices.append(faceIndices[i + 1]);
        }
    }
}

int ObjLoader::findOrAddVertex(const QVector3D& vertex, const QVector2D& uv, const QVector3D& normal)
{
    // 查找是否已存在相同的顶点
    for (int i = 0; i < vertices.size(); ++i) {
        const Vertex& v = vertices[i];
        if (v.position == vertex && v.texCoord == uv && v.normal == normal) {
            return i;
        }
    }
    
    // 如果不存在，添加新顶点
    Vertex newVertex;
    newVertex.position = vertex;
    newVertex.texCoord = uv;
    newVertex.normal = normal;
    
    vertices.append(newVertex);
    return vertices.size() - 1;
}

void ObjLoader::clear()
{
    temp_vertices.clear();
    temp_uvs.clear();
    temp_normals.clear();
    vertices.clear();
    indices.clear();
}
