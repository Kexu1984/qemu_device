#ifndef OBJVIEWERWIDGET_H
#define OBJVIEWERWIDGET_H

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QMatrix4x4>
#include <QTimer>
#include "objloader.h"

class ObjViewerWidget : public QOpenGLWidget, protected QOpenGLFunctions
{
    Q_OBJECT

public:
    explicit ObjViewerWidget(QWidget *parent = nullptr);
    ~ObjViewerWidget();
    
    bool loadModel(const QString& filePath);

protected:
    void initializeGL() override;
    void resizeGL(int w, int h) override;
    void paintGL() override;
    
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;

private slots:
    void animate();

private:
    bool initShaders();
    void setupGeometry();
    void cleanup();
    
    // OpenGL对象
    QOpenGLShaderProgram *m_program;
    QOpenGLBuffer m_vertexBuffer;
    QOpenGLBuffer m_indexBuffer;
    
    // 着色器属性和uniform位置
    int m_positionAttr;
    int m_texCoordAttr;
    int m_normalAttr;
    int m_mvpMatrixUniform;
    int m_modelMatrixUniform;
    int m_normalMatrixUniform;
    int m_lightDirectionUniform;
    int m_lightColorUniform;
    int m_ambientColorUniform;
    int m_diffuseColorUniform;
    
    // 变换矩阵
    QMatrix4x4 m_projection;
    QMatrix4x4 m_view;
    QMatrix4x4 m_model;
    
    // 相机控制
    float m_rotationX;
    float m_rotationY;
    float m_distance;
    QPoint m_lastMousePos;
    
    // 模型数据
    ObjLoader m_objLoader;
    int m_indexCount;
    
    // 动画
    QTimer *m_timer;
    float m_time;
    
    bool m_modelLoaded;
};

#endif // OBJVIEWERWIDGET_H
