#include "objviewerwidget.h"
#include <QMouseEvent>
#include <QWheelEvent>
#include <QOpenGLShader>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QtMath>

ObjViewerWidget::ObjViewerWidget(QWidget *parent)
    : QOpenGLWidget(parent)
    , m_program(nullptr)
    , m_vertexBuffer(QOpenGLBuffer::VertexBuffer)
    , m_indexBuffer(QOpenGLBuffer::IndexBuffer)
    , m_positionAttr(-1)
    , m_texCoordAttr(-1)
    , m_normalAttr(-1)
    , m_mvpMatrixUniform(-1)
    , m_modelMatrixUniform(-1)
    , m_normalMatrixUniform(-1)
    , m_lightDirectionUniform(-1)
    , m_lightColorUniform(-1)
    , m_ambientColorUniform(-1)
    , m_diffuseColorUniform(-1)
    , m_rotationX(0.0f)
    , m_rotationY(0.0f)
    , m_distance(5.0f)
    , m_indexCount(0)
    , m_timer(new QTimer(this))
    , m_time(0.0f)
    , m_modelLoaded(false)
{
    connect(m_timer, &QTimer::timeout, this, &ObjViewerWidget::animate);
    m_timer->start(16); // ~60 FPS
}

ObjViewerWidget::~ObjViewerWidget()
{
    cleanup();
}

bool ObjViewerWidget::loadModel(const QString& filePath)
{
    if (m_objLoader.loadOBJ(filePath)) {
        m_modelLoaded = true;
        if (context()) {
            makeCurrent();
            setupGeometry();
            doneCurrent();
        }
        return true;
    }
    return false;
}

void ObjViewerWidget::initializeGL()
{
    initializeOpenGLFunctions();
    
    // 启用深度测试
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    
    // 启用背面剔除
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    
    // 设置清除颜色
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
    
    // 初始化着色器
    if (!initShaders()) {
        qDebug() << "Failed to initialize shaders";
        return;
    }
    
    // 如果已经加载了模型，设置几何体
    if (m_modelLoaded) {
        setupGeometry();
    }
}

void ObjViewerWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
    
    // 设置投影矩阵
    m_projection.setToIdentity();
    float aspect = float(w) / float(h);
    m_projection.perspective(45.0f, aspect, 0.1f, 100.0f);
}

void ObjViewerWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    if (!m_program || !m_modelLoaded || m_indexCount == 0) {
        return;
    }
    
    m_program->bind();
    
    // 设置视图矩阵
    m_view.setToIdentity();
    m_view.translate(0, 0, -m_distance);
    m_view.rotate(m_rotationX, 1, 0, 0);
    m_view.rotate(m_rotationY, 0, 1, 0);
    
    // 设置模型矩阵（添加轻微自旋转）
    m_model.setToIdentity();
    m_model.rotate(m_time * 20.0f, 0, 1, 0);
    
    // 计算MVP矩阵
    QMatrix4x4 mvp = m_projection * m_view * m_model;
    
    // 计算法线矩阵
    QMatrix3x3 normalMatrix = m_model.normalMatrix();
    
    // 设置uniform变量
    m_program->setUniformValue(m_mvpMatrixUniform, mvp);
    m_program->setUniformValue(m_modelMatrixUniform, m_model);
    m_program->setUniformValue(m_normalMatrixUniform, normalMatrix);
    
    // 设置光照参数
    m_program->setUniformValue(m_lightDirectionUniform, QVector3D(1.0f, 1.0f, 1.0f));
    m_program->setUniformValue(m_lightColorUniform, QVector3D(1.0f, 1.0f, 1.0f));
    m_program->setUniformValue(m_ambientColorUniform, QVector3D(0.2f, 0.2f, 0.2f));
    m_program->setUniformValue(m_diffuseColorUniform, QVector3D(0.8f, 0.6f, 0.4f));
    
    // 绑定缓冲区
    m_vertexBuffer.bind();
    m_indexBuffer.bind();
    
    // 设置顶点属性
    int stride = sizeof(Vertex);
    
    glEnableVertexAttribArray(m_positionAttr);
    glVertexAttribPointer(m_positionAttr, 3, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(offsetof(Vertex, position)));
    
    glEnableVertexAttribArray(m_texCoordAttr);
    glVertexAttribPointer(m_texCoordAttr, 2, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(offsetof(Vertex, texCoord)));
    
    glEnableVertexAttribArray(m_normalAttr);
    glVertexAttribPointer(m_normalAttr, 3, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(offsetof(Vertex, normal)));
    
    // 使用glDrawElements绘制
    glDrawElements(GL_TRIANGLES, m_indexCount, GL_UNSIGNED_INT, nullptr);
    
    // 禁用顶点属性
    glDisableVertexAttribArray(m_positionAttr);
    glDisableVertexAttribArray(m_texCoordAttr);
    glDisableVertexAttribArray(m_normalAttr);
    
    m_indexBuffer.release();
    m_vertexBuffer.release();
    m_program->release();
}

void ObjViewerWidget::mousePressEvent(QMouseEvent *event)
{
    m_lastMousePos = event->pos();
}

void ObjViewerWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) {
        QPoint delta = event->pos() - m_lastMousePos;
        m_rotationX += delta.y() * 0.5f;
        m_rotationY += delta.x() * 0.5f;
        
        // 限制X轴旋转角度
        if (m_rotationX > 90.0f) m_rotationX = 90.0f;
        if (m_rotationX < -90.0f) m_rotationX = -90.0f;
        
        update();
    }
    m_lastMousePos = event->pos();
}

void ObjViewerWidget::wheelEvent(QWheelEvent *event)
{
    float delta = event->delta() / 120.0f;
    m_distance -= delta * 0.5f;
    
    // 限制距离
    if (m_distance < 1.0f) m_distance = 1.0f;
    if (m_distance > 20.0f) m_distance = 20.0f;
    
    update();
}

void ObjViewerWidget::animate()
{
    m_time += 0.016f; // 约60fps
    update();
}

bool ObjViewerWidget::initShaders()
{
    m_program = new QOpenGLShaderProgram(this);
    
    // 读取顶点着色器
    QFile vertexFile(":/shaders/vertex.glsl");
    if (!vertexFile.open(QIODevice::ReadOnly)) {
        qDebug() << "Cannot open vertex shader file";
        return false;
    }
    QString vertexSource = QTextStream(&vertexFile).readAll();
    vertexFile.close();
    
    // 读取片段着色器
    QFile fragmentFile(":/shaders/fragment.glsl");
    if (!fragmentFile.open(QIODevice::ReadOnly)) {
        qDebug() << "Cannot open fragment shader file";
        return false;
    }
    QString fragmentSource = QTextStream(&fragmentFile).readAll();
    fragmentFile.close();
    
    // 编译着色器
    if (!m_program->addShaderFromSourceCode(QOpenGLShader::Vertex, vertexSource)) {
        qDebug() << "Vertex shader compilation failed:" << m_program->log();
        return false;
    }
    
    if (!m_program->addShaderFromSourceCode(QOpenGLShader::Fragment, fragmentSource)) {
        qDebug() << "Fragment shader compilation failed:" << m_program->log();
        return false;
    }
    
    // 链接着色器程序
    if (!m_program->link()) {
        qDebug() << "Shader program linking failed:" << m_program->log();
        return false;
    }
    
    // 获取属性和uniform位置
    m_positionAttr = m_program->attributeLocation("aPosition");
    m_texCoordAttr = m_program->attributeLocation("aTexCoord");
    m_normalAttr = m_program->attributeLocation("aNormal");
    
    m_mvpMatrixUniform = m_program->uniformLocation("uMvpMatrix");
    m_modelMatrixUniform = m_program->uniformLocation("uModelMatrix");
    m_normalMatrixUniform = m_program->uniformLocation("uNormalMatrix");
    m_lightDirectionUniform = m_program->uniformLocation("uLightDirection");
    m_lightColorUniform = m_program->uniformLocation("uLightColor");
    m_ambientColorUniform = m_program->uniformLocation("uAmbientColor");
    m_diffuseColorUniform = m_program->uniformLocation("uDiffuseColor");
    
    qDebug() << "Shaders initialized successfully";
    return true;
}

void ObjViewerWidget::setupGeometry()
{
    const QVector<Vertex>& vertices = m_objLoader.getVertices();
    const QVector<unsigned int>& indices = m_objLoader.getIndices();
    
    if (vertices.isEmpty() || indices.isEmpty()) {
        qDebug() << "No geometry data to setup";
        return;
    }
    
    // 创建并填充顶点缓冲区
    m_vertexBuffer.create();
    m_vertexBuffer.bind();
    m_vertexBuffer.allocate(vertices.data(), vertices.size() * sizeof(Vertex));
    m_vertexBuffer.release();
    
    // 创建并填充索引缓冲区
    m_indexBuffer.create();
    m_indexBuffer.bind();
    m_indexBuffer.allocate(indices.data(), indices.size() * sizeof(unsigned int));
    m_indexBuffer.release();
    
    m_indexCount = indices.size();
    
    qDebug() << "Geometry setup complete. Vertices:" << vertices.size() << "Indices:" << indices.size();
}

void ObjViewerWidget::cleanup()
{
    makeCurrent();
    
    if (m_vertexBuffer.isCreated()) {
        m_vertexBuffer.destroy();
    }
    
    if (m_indexBuffer.isCreated()) {
        m_indexBuffer.destroy();
    }
    
    delete m_program;
    m_program = nullptr;
    
    doneCurrent();
}
