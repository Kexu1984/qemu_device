#include "GLView.h"
#include <QDebug>
#include <QDir>
#include <cmath>

GLView::GLView(QWidget *parent)
    : QOpenGLWidget(parent)
    , m_camera(nullptr)
    , m_objLoader(nullptr)
    , m_shaderProgram(nullptr)
    , m_diffuseTexture(nullptr)
    , m_vbo(0)
    , m_ibo(0)
    , m_indexCount(0)
    , m_mousePressed(false)
    , m_wireframeMode(false)
    , m_frameCount(0)
    , m_fps(0.0f)
    , m_lightDirection(-0.5f, -1.0f, -0.5f)
{
    // 设置焦点策略以接收键盘事件
    setFocusPolicy(Qt::StrongFocus);
    
    // 初始化相机
    m_camera = new Camera(this);
    
    // 初始化OBJ加载器
    m_objLoader = new ObjLoader(this);
    
    // 初始化FPS计时器
    m_fpsTimer = new QTimer(this);
    connect(m_fpsTimer, &QTimer::timeout, this, &GLView::updateFPS);
    m_fpsTimer->start(1000); // 每秒更新一次FPS
    m_frameTimer.start();
}

GLView::~GLView()
{
    makeCurrent();
    
    if (m_vbo) {
        glDeleteBuffers(1, &m_vbo);
    }
    if (m_ibo) {
        glDeleteBuffers(1, &m_ibo);
    }
    
    delete m_shaderProgram;
    delete m_diffuseTexture;
    
    doneCurrent();
}

void GLView::initializeGL()
{
    initializeOpenGLFunctions();
    
    qDebug() << "OpenGL Version:" << (const char*)glGetString(GL_VERSION);
    qDebug() << "OpenGL Vendor:" << (const char*)glGetString(GL_VENDOR);
    qDebug() << "OpenGL Renderer:" << (const char*)glGetString(GL_RENDERER);
    
    // 设置OpenGL状态
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW); // 逆时针为正面
    
    glClearColor(0.2f, 0.3f, 0.4f, 1.0f);
    
    // 设置着色器
    setupShaders();
    
    // 加载网格
    setupMesh();
    
    // 设置纹理
    setupTextures();
    
    checkGLError("初始化完成");
}

void GLView::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    if (m_indexCount > 0 && m_shaderProgram && m_shaderProgram->isLinked()) {
        renderMesh();
    }
    
    m_frameCount++;
}

void GLView::resizeGL(int width, int height)
{
    glViewport(0, 0, width, height);
    m_camera->setAspectRatio(float(width) / float(height));
}

void GLView::setupShaders()
{
    m_shaderProgram = new ShaderProgram(this);
    
    // 加载顶点着色器
    QString vertexShaderPath = ":/shaders/mesh.glsl.vert";
    QString fragmentShaderPath = ":/shaders/mesh.glsl.frag";
    
    if (!m_shaderProgram->loadFromFiles(vertexShaderPath, fragmentShaderPath)) {
        qDebug() << "着色器加载失败";
        return;
    }
    
    // 获取属性位置
    m_positionLoc = m_shaderProgram->attributeLocation("a_position");
    m_normalLoc = m_shaderProgram->attributeLocation("a_normal");
    m_texcoordLoc = m_shaderProgram->attributeLocation("a_texcoord");
    
    // 获取uniform位置
    m_mvpLoc = m_shaderProgram->uniformLocation("u_mvp");
    m_modelLoc = m_shaderProgram->uniformLocation("u_model");
    m_lightDirLoc = m_shaderProgram->uniformLocation("u_lightDir");
    m_diffuseLoc = m_shaderProgram->uniformLocation("u_diffuse");
    
    qDebug() << "着色器编译成功";
    qDebug() << "属性位置 - position:" << m_positionLoc << "normal:" << m_normalLoc << "texcoord:" << m_texcoordLoc;
}

void GLView::setupMesh()
{
    // 尝试加载默认OBJ文件
    QString objPath = "assets/model.obj";
    if (!QDir::current().exists(objPath)) {
        qDebug() << "未找到" << objPath << "，创建默认立方体";
        m_objLoader->createDefaultCube();
    } else {
        if (!m_objLoader->loadFromFile(objPath)) {
            qDebug() << "OBJ加载失败，使用默认立方体";
            m_objLoader->createDefaultCube();
        }
    }
    
    const auto& vertices = m_objLoader->getVertices();
    const auto& indices = m_objLoader->getIndices();
    
    if (vertices.isEmpty() || indices.isEmpty()) {
        qDebug() << "网格数据为空";
        return;
    }
    
    m_indexCount = indices.size();
    
    // 计算网格边界用于相机初始化
    QVector3D minBounds, maxBounds;
    m_objLoader->getBounds(minBounds, maxBounds);
    m_meshCenter = (minBounds + maxBounds) * 0.5f;
    QVector3D extent = maxBounds - minBounds;
    m_meshScale = qMax(qMax(extent.x(), extent.y()), extent.z());
    
    // 创建VBO
    glGenBuffers(1, &m_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(ObjLoader::Vertex), 
                 vertices.constData(), GL_STATIC_DRAW);
    
    // 创建IBO
    glGenBuffers(1, &m_ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned short), 
                 indices.constData(), GL_STATIC_DRAW);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    
    // 设置相机初始位置
    resetCamera();
    
    qDebug() << "网格上传完成 - 顶点数:" << vertices.size() << "索引数:" << indices.size();
    qDebug() << "网格边界:" << minBounds << "到" << maxBounds;
    
    checkGLError("网格设置");
}

void GLView::setupTextures()
{
    m_diffuseTexture = new Texture(this);
    
    // 尝试加载纹理
    QString texturePath = "assets/diffuse.jpg";
    if (!QDir::current().exists(texturePath)) {
        texturePath = "assets/diffuse.png";
    }
    
    if (!QDir::current().exists(texturePath)) {
        qDebug() << "未找到纹理文件，创建默认白色纹理";
        m_diffuseTexture->createDefault();
    } else {
        if (!m_diffuseTexture->loadFromFile(texturePath)) {
            qDebug() << "纹理加载失败，使用默认纹理";
            m_diffuseTexture->createDefault();
        }
    }
    
    checkGLError("纹理设置");
}

void GLView::renderMesh()
{
    // 使用着色器程序
    glUseProgram(m_shaderProgram->programId());
    
    // 设置矩阵
    QMatrix4x4 model;
    model.translate(-m_meshCenter); // 将模型中心移到原点
    
    QMatrix4x4 mvp = m_camera->getProjectionMatrix() * m_camera->getViewMatrix() * model;
    
    glUniformMatrix4fv(m_mvpLoc, 1, GL_FALSE, mvp.constData());
    glUniformMatrix4fv(m_modelLoc, 1, GL_FALSE, model.constData());
    
    // 设置光照方向
    QVector3D normalizedLight = m_lightDirection.normalized();
    glUniform3f(m_lightDirLoc, normalizedLight.x(), normalizedLight.y(), normalizedLight.z());
    
    // 绑定纹理
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, m_diffuseTexture->textureId());
    glUniform1i(m_diffuseLoc, 0);
    
    // 绑定顶点数据
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ibo);
    
    // 设置顶点属性指针（交错格式：position, normal, texcoord）
    const int stride = sizeof(ObjLoader::Vertex);
    
    glEnableVertexAttribArray(m_positionLoc);
    glVertexAttribPointer(m_positionLoc, 3, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(0));
    
    glEnableVertexAttribArray(m_normalLoc);
    glVertexAttribPointer(m_normalLoc, 3, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(3 * sizeof(float)));
    
    glEnableVertexAttribArray(m_texcoordLoc);
    glVertexAttribPointer(m_texcoordLoc, 2, GL_FLOAT, GL_FALSE, stride, 
                         reinterpret_cast<void*>(6 * sizeof(float)));
    
    // 绘制网格
    glDrawElements(GL_TRIANGLES, m_indexCount, GL_UNSIGNED_SHORT, 0);
    
    // 清理状态
    glDisableVertexAttribArray(m_positionLoc);
    glDisableVertexAttribArray(m_normalLoc);
    glDisableVertexAttribArray(m_texcoordLoc);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    glBindTexture(GL_TEXTURE_2D, 0);
    glUseProgram(0);
}

void GLView::keyPressEvent(QKeyEvent *event)
{
    switch (event->key()) {
    case Qt::Key_R:
        resetCamera();
        update();
        break;
    case Qt::Key_W:
        m_wireframeMode = !m_wireframeMode;
        qDebug() << "线框模式:" << (m_wireframeMode ? "开启" : "关闭") 
                 << "(注意：ES2不支持glPolygonMode)";
        break;
    default:
        QOpenGLWidget::keyPressEvent(event);
    }
}

void GLView::mousePressEvent(QMouseEvent *event)
{
    m_lastMousePos = event->pos();
    m_mousePressed = true;
    m_pressedButton = event->button();
}

void GLView::mouseMoveEvent(QMouseEvent *event)
{
    if (!m_mousePressed) return;
    
    QPoint delta = event->pos() - m_lastMousePos;
    
    if (m_pressedButton == Qt::LeftButton) {
        // 轨道旋转
        m_camera->orbit(delta.x() * 0.5f, delta.y() * 0.5f);
    } else if (m_pressedButton == Qt::RightButton) {
        // 平移
        m_camera->pan(delta.x() * 0.01f, -delta.y() * 0.01f);
    }
    
    m_lastMousePos = event->pos();
    update();
}

void GLView::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event)
    m_mousePressed = false;
}

void GLView::wheelEvent(QWheelEvent *event)
{
    float delta = event->angleDelta().y() / 120.0f;
    m_camera->zoom(delta * 0.1f);
    update();
}

void GLView::resetCamera()
{
    if (m_camera && m_meshScale > 0) {
        float distance = m_meshScale * 2.0f;
        m_camera->resetToPosition(QVector3D(0, 0, distance), QVector3D(0, 0, 0));
    }
}

void GLView::updateFPS()
{
    qint64 elapsed = m_frameTimer.elapsed();
    if (elapsed > 0) {
        m_fps = m_frameCount * 1000.0f / elapsed;
        setWindowTitle(QString("3D OBJ Renderer - FPS: %1").arg(m_fps, 0, 'f', 1));
    }
    m_frameCount = 0;
    m_frameTimer.restart();
}

void GLView::checkGLError(const QString &operation)
{
    GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        qDebug() << "OpenGL错误在" << operation << ":" << error;
    }
}
