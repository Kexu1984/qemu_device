#ifndef CAMERA_H
#define CAMERA_H

#include <QObject>
#include <QMatrix4x4>
#include <QVector3D>

class Camera : public QObject
{
    Q_OBJECT

public:
    explicit Camera(QObject *parent = nullptr);

    // 获取矩阵
    QMatrix4x4 getViewMatrix() const;
    QMatrix4x4 getProjectionMatrix() const;
    
    // 相机控制
    void orbit(float deltaX, float deltaY);  // 轨道旋转
    void pan(float deltaX, float deltaY);    // 平移
    void zoom(float delta);                  // 缩放
    
    // 设置
    void setAspectRatio(float aspectRatio);
    void setFov(float fov);
    void setNearFar(float nearPlane, float farPlane);
    
    // 重置相机
    void resetToPosition(const QVector3D &position, const QVector3D &target);

    // 获取相机参数
    QVector3D getPosition() const { return m_position; }
    QVector3D getTarget() const { return m_target; }
    float getDistance() const { return m_distance; }

private:
    void updatePosition();
    void updateProjection();

    // 相机参数
    QVector3D m_position;
    QVector3D m_target;
    QVector3D m_up;
    
    // 轨道相机参数
    float m_distance;
    float m_azimuth;    // 水平角度
    float m_elevation;  // 垂直角度
    
    // 投影参数
    float m_fov;
    float m_aspectRatio;
    float m_nearPlane;
    float m_farPlane;
    
    // 缓存的矩阵
    mutable QMatrix4x4 m_viewMatrix;
    mutable QMatrix4x4 m_projectionMatrix;
    mutable bool m_viewDirty;
    mutable bool m_projectionDirty;
};

#endif // CAMERA_H
