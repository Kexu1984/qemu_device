#!/bin/bash

# 3D OBJ渲染器编译脚本
# 适用于Qt 5.6.3 + OpenGL ES 2.0

set -e

PROJECT_NAME="render_3d_obj"
BUILD_DIR="build"

echo "=== 3D OBJ渲染器编译脚本 ==="
echo "目标平台: Qt 5.6.3 + OpenGL ES 2.0"
echo "GPU优化: ARM Mali-400"
echo ""

# 检测编译模式
if [ "$1" == "embedded" ]; then
    echo "编译模式: 嵌入式ARM平台"
    CONFIG_FLAGS="CONFIG+=embedded"
elif [ "$1" == "debug" ]; then
    echo "编译模式: 桌面调试"
    CONFIG_FLAGS="CONFIG+=debug"
else
    echo "编译模式: 桌面发布"
    CONFIG_FLAGS=""
fi

# 创建构建目录
if [ -d "$BUILD_DIR" ]; then
    echo "清理旧的构建目录..."
    rm -rf "$BUILD_DIR"
fi

mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo "正在配置项目..."
qmake ../${PROJECT_NAME}.pro $CONFIG_FLAGS

echo "正在编译..."
make -j$(nproc)

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 编译成功！"
    echo "可执行文件: $BUILD_DIR/$PROJECT_NAME"
    
    # 复制资源文件
    if [ -d "../assets" ]; then
        echo "复制资源文件..."
        cp -r ../assets .
    fi
    
    echo ""
    echo "运行说明:"
    if [ "$1" == "embedded" ]; then
        echo "1. 将可执行文件和assets文件夹复制到目标设备"
        echo "2. 在目标设备上设置环境变量:"
        echo "   export QT_QPA_PLATFORM=eglfs"
        echo "   export QT_QPA_EGLFS_INTEGRATION=eglfs_mali"
        echo "3. 运行: ./$PROJECT_NAME"
    else
        echo "桌面运行: ./$PROJECT_NAME"
        echo "控制方式:"
        echo "  - 鼠标左键拖拽: 轨道旋转"
        echo "  - 鼠标右键拖拽: 平移"
        echo "  - 鼠标滚轮: 缩放"
        echo "  - R键: 重置相机"
    fi
else
    echo "❌ 编译失败！"
    echo "请检查错误信息并修正问题。"
    exit 1
fi
