#ifndef OBJLOADER_H
#define OBJLOADER_H

#include <QObject>
#include <QVector>
#include <QVector3D>
#include <QVector2D>
#include <QString>
#include <QHash>

class ObjLoader : public QObject
{
    Q_OBJECT

public:
    // 顶点结构体（交错格式：position, normal, texcoord）
    struct Vertex {
        QVector3D position;
        QVector3D normal;
        QVector2D texcoord;
        
        Vertex() = default;
        Vertex(const QVector3D &pos, const QVector3D &norm, const QVector2D &uv)
            : position(pos), normal(norm), texcoord(uv) {}
            
        bool operator==(const Vertex &other) const {
            return position == other.position && 
                   normal == other.normal && 
                   texcoord == other.texcoord;
        }
    };

    explicit ObjLoader(QObject *parent = nullptr);

    // 从文件加载OBJ
    bool loadFromFile(const QString &filename);
    
    // 创建默认立方体（用于测试）
    void createDefaultCube();
    
    // 获取处理后的顶点和索引数据
    const QVector<Vertex>& getVertices() const { return m_vertices; }
    const QVector<unsigned short>& getIndices() const { return m_indices; }
    
    // 获取网格边界
    void getBounds(QVector3D &minBounds, QVector3D &maxBounds) const;
    
    // 获取统计信息
    int getVertexCount() const { return m_vertices.size(); }
    int getTriangleCount() const { return m_indices.size() / 3; }

private:
    struct FaceVertex {
        int positionIndex;
        int normalIndex;
        int texcoordIndex;
        
        FaceVertex() : positionIndex(-1), normalIndex(-1), texcoordIndex(-1) {}
        FaceVertex(int p, int n, int t) : positionIndex(p), normalIndex(n), texcoordIndex(t) {}
        
        bool operator==(const FaceVertex &other) const {
            return positionIndex == other.positionIndex &&
                   normalIndex == other.normalIndex &&
                   texcoordIndex == other.texcoordIndex;
        }
    };

    void clear();
    bool parseLine(const QString &line);
    void processFace(const QStringList &tokens);
    FaceVertex parseFaceVertex(const QString &vertexStr);
    void triangulate(const QVector<FaceVertex> &faceVertices);
    void optimizeVertices();
    void generateNormals();
    void calculateBounds();
    
    // 原始解析数据
    QVector<QVector3D> m_positions;
    QVector<QVector3D> m_normals;
    QVector<QVector2D> m_texcoords;
    QVector<QVector<FaceVertex>> m_faces;
    
    // 优化后的顶点和索引数据
    QVector<Vertex> m_vertices;
    QVector<unsigned short> m_indices;
    
    // 边界信息
    QVector3D m_minBounds;
    QVector3D m_maxBounds;
    
    // 用于顶点去重的哈希表
    QHash<FaceVertex, unsigned short> m_vertexMap;
};

// 为FaceVertex实现哈希函数
inline uint qHash(const ObjLoader::FaceVertex &vertex, uint seed = 0)
{
    return qHashMulti(seed, vertex.positionIndex, vertex.normalIndex, vertex.texcoordIndex);
}

#endif // OBJLOADER_H
