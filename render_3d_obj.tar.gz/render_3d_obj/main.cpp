#include <QApplication>
#include <QSurfaceFormat>
#include "GLView.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    
    // 配置OpenGL ES 2.0上下文
    QSurfaceFormat format;
    format.setVersion(2, 0);
    format.setRenderableType(QSurfaceFormat::OpenGLES);
    format.setDepthBufferSize(24);
    format.setStencilBufferSize(8);
    format.setSamples(4); // MSAA，Mali-400支持
    format.setSwapBehavior(QSurfaceFormat::DoubleBuffer);
    QSurfaceFormat::setDefaultFormat(format);
    
#ifdef DEBUG_MODE
    qDebug() << "Starting 3D OBJ Renderer for OpenGL ES 2.0";
    qDebug() << "Target platform: ARM Mali-400 GPU";
#endif
    
    GLView viewer;
    viewer.setWindowTitle("3D OBJ Renderer - Qt 5.6.3 + OpenGL ES 2.0");
    viewer.resize(800, 600);
    viewer.show();
    
    return app.exec();
}
