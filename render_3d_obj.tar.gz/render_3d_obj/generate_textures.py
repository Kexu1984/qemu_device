#!/usr/bin/env python3
"""
简单的纹理生成器
为3D OBJ渲染器生成测试纹理
"""

import os
import sys

try:
    from PIL import Image, ImageDraw
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

def create_checkerboard_texture(size=256, square_size=32):
    """创建棋盘格纹理"""
    if not PIL_AVAILABLE:
        print("警告: 未安装PIL/Pillow，无法生成纹理")
        return False
    
    image = Image.new('RGB', (size, size), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    
    squares_per_side = size // square_size
    
    for i in range(squares_per_side):
        for j in range(squares_per_side):
            if (i + j) % 2 == 1:
                x1 = i * square_size
                y1 = j * square_size
                x2 = x1 + square_size
                y2 = y1 + square_size
                draw.rectangle([x1, y1, x2, y2], fill=(128, 128, 128))
    
    return image

def create_gradient_texture(size=256):
    """创建渐变纹理"""
    if not PIL_AVAILABLE:
        return False
    
    image = Image.new('RGB', (size, size))
    
    for y in range(size):
        for x in range(size):
            # 从左上角到右下角的渐变
            r = int(255 * x / size)
            g = int(255 * y / size)
            b = int(255 * (1.0 - (x + y) / (2 * size)))
            image.putpixel((x, y), (r, g, b))
    
    return image

def main():
    assets_dir = "assets"
    
    if not os.path.exists(assets_dir):
        os.makedirs(assets_dir)
        print(f"创建资源目录: {assets_dir}")
    
    if PIL_AVAILABLE:
        # 生成棋盘格纹理
        checkerboard = create_checkerboard_texture()
        if checkerboard:
            checkerboard.save(os.path.join(assets_dir, "diffuse.png"))
            print("✅ 生成棋盘格纹理: assets/diffuse.png")
        
        # 生成渐变纹理作为备选
        gradient = create_gradient_texture()
        if gradient:
            gradient.save(os.path.join(assets_dir, "gradient.png"))
            print("✅ 生成渐变纹理: assets/gradient.png")
    else:
        print("❌ 无法生成纹理文件")
        print("请安装PIL: pip install Pillow")
        print("或手动放置纹理文件到 assets/diffuse.jpg 或 assets/diffuse.png")
    
    print("\n纹理生成完成！")

if __name__ == "__main__":
    main()
