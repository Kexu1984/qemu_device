#include "Texture.h"
#include <QImage>
#include <QDebug>

// 辅助函数声明
static bool isPowerOfTwo(int value)
{
    return value > 0 && (value & (value - 1)) == 0;
}

Texture::Texture(QObject *parent)
    : QObject(parent)
    , m_textureId(0)
    , m_width(0)
    , m_height(0)
    , m_format(GL_RGB)
{
    initializeOpenGLFunctions();
}

Texture::~Texture()
{
    cleanup();
}

bool Texture::loadFromFile(const QString &filename)
{
    QImage image(filename);
    if (image.isNull()) {
        qDebug() << "无法加载纹理文件:" << filename;
        return false;
    }
    
    qDebug() << "加载纹理:" << filename << "尺寸:" << image.width() << "x" << image.height();
    
    return createFromImage(image);
}

void Texture::createDefault()
{
    // 创建1x1白色纹理
    QImage whiteImage(1, 1, QImage::Format_RGB888);
    whiteImage.fill(QColor(255, 255, 255));
    
    if (createFromImage(whiteImage)) {
        qDebug() << "创建默认白色纹理成功";
    } else {
        qDebug() << "创建默认纹理失败";
    }
}

bool Texture::createFromImage(const QImage &image)
{
    if (image.isNull()) {
        qDebug() << "输入图像为空";
        return false;
    }
    
    cleanup();
    
    // 转换图像格式为OpenGL ES 2.0兼容格式
    QImage glImage = image.convertToFormat(QImage::Format_RGB888);
    
    // 翻转Y轴（Qt图像坐标系与OpenGL纹理坐标系不同）
    glImage = glImage.mirrored(false, true);
    
    m_width = glImage.width();
    m_height = glImage.height();
    m_format = GL_RGB;
    
    // 生成纹理对象
    glGenTextures(1, &m_textureId);
    if (m_textureId == 0) {
        qDebug() << "生成纹理对象失败";
        return false;
    }
    
    // 绑定纹理
    glBindTexture(GL_TEXTURE_2D, m_textureId);
    
    // 上传纹理数据
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, m_width, m_height, 0, 
                 GL_RGB, GL_UNSIGNED_BYTE, glImage.constBits());
    
    // 检查是否支持mipmap生成
    bool supportsMipmap = true;
    
    // Mali-400友好的纹理参数设置
    if (supportsMipmap && isPowerOfTwo(m_width) && isPowerOfTwo(m_height)) {
        // 生成mipmap（仅对2的幂尺寸）
        glGenerateMipmap(GL_TEXTURE_2D);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        qDebug() << "纹理启用mipmap";
    } else {
        // 线性过滤
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        if (!isPowerOfTwo(m_width) || !isPowerOfTwo(m_height)) {
            qDebug() << "纹理尺寸非2的幂，禁用mipmap";
        }
    }
    
    // 设置纹理包装模式
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    
    glBindTexture(GL_TEXTURE_2D, 0);
    
    // 检查OpenGL错误
    GLenum error = glGetError();
    if (error != GL_NO_ERROR) {
        qDebug() << "纹理创建时OpenGL错误:" << error;
        cleanup();
        return false;
    }
    
    qDebug() << "纹理创建成功，ID:" << m_textureId << "尺寸:" << m_width << "x" << m_height;
    return true;
}

void Texture::bind(GLenum textureUnit)
{
    if (m_textureId != 0) {
        glActiveTexture(textureUnit);
        glBindTexture(GL_TEXTURE_2D, m_textureId);
    }
}

void Texture::unbind()
{
    glBindTexture(GL_TEXTURE_2D, 0);
}

void Texture::cleanup()
{
    if (m_textureId != 0) {
        glDeleteTextures(1, &m_textureId);
        m_textureId = 0;
    }
    m_width = 0;
    m_height = 0;
}

void Texture::setupTextureParameters()
{
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}
