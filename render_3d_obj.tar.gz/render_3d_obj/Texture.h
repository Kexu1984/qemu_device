#ifndef TEXTURE_H
#define TEXTURE_H

#include <QObject>
#include <QOpenGLFunctions_ES2>
#include <QString>

class Texture : public QObject, protected QOpenGLFunctions_ES2
{
    Q_OBJECT

public:
    explicit Texture(QObject *parent = nullptr);
    ~Texture();

    // 从文件加载纹理
    bool loadFromFile(const QString &filename);
    
    // 创建默认白色纹理
    void createDefault();
    
    // 从QImage创建纹理
    bool createFromImage(const QImage &image);
    
    // 绑定纹理
    void bind(GLenum textureUnit = GL_TEXTURE0);
    void unbind();
    
    // 获取纹理ID
    GLuint textureId() const { return m_textureId; }
    
    // 状态查询
    bool isValid() const { return m_textureId != 0; }
    
    // 获取纹理信息
    int width() const { return m_width; }
    int height() const { return m_height; }

private:
    void cleanup();
    void setupTextureParameters();
    
    GLuint m_textureId;
    int m_width;
    int m_height;
    GLenum m_format;
};

#endif // TEXTURE_H
