#ifndef GLVIEW_H
#define GLVIEW_H

#include <QOpenGLWidget>
#include <QOpenGLFunctions_ES2>
#include <QMatrix4x4>
#include <QVector3D>
#include <QElapsedTimer>
#include <QTimer>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QWheelEvent>

#include "Camera.h"
#include "ObjLoader.h"
#include "ShaderProgram.h"
#include "Texture.h"

class GLView : public QOpenGLWidget, protected QOpenGLFunctions_ES2
{
    Q_OBJECT

public:
    explicit GLView(QWidget *parent = nullptr);
    ~GLView();

protected:
    // OpenGL重写函数
    void initializeGL() override;
    void paintGL() override;
    void resizeGL(int width, int height) override;
    
    // 事件处理
    void keyPressEvent(QKeyEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;
    void wheelEvent(QWheelEvent *event) override;

private slots:
    void updateFPS();

private:
    void setupMesh();
    void setupShaders();
    void setupTextures();
    void renderMesh();
    void resetCamera();
    void checkGLError(const QString &operation);
    
    // 渲染相关
    Camera *m_camera;
    ObjLoader *m_objLoader;
    ShaderProgram *m_shaderProgram;
    Texture *m_diffuseTexture;
    
    // OpenGL缓冲对象
    GLuint m_vbo;  // 顶点缓冲对象
    GLuint m_ibo;  // 索引缓冲对象
    
    // 着色器属性位置
    GLint m_positionLoc;
    GLint m_normalLoc;
    GLint m_texcoordLoc;
    
    // 着色器uniform位置
    GLint m_mvpLoc;
    GLint m_modelLoc;
    GLint m_lightDirLoc;
    GLint m_diffuseLoc;
    
    // 网格数据
    int m_indexCount;
    QVector3D m_meshCenter;
    float m_meshScale;
    
    // 交互状态
    QPoint m_lastMousePos;
    bool m_mousePressed;
    Qt::MouseButton m_pressedButton;
    bool m_wireframeMode;
    
    // 性能监控
    QElapsedTimer m_frameTimer;
    QTimer *m_fpsTimer;
    int m_frameCount;
    float m_fps;
    
    // 光照参数
    QVector3D m_lightDirection;
};

#endif // GLVIEW_H
