#include "ShaderProgram.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>

ShaderProgram::ShaderProgram(QObject *parent)
    : QObject(parent)
    , m_programId(0)
    , m_vertexShaderId(0)
    , m_fragmentShaderId(0)
    , m_linked(false)
{
    initializeOpenGLFunctions();
}

ShaderProgram::~ShaderProgram()
{
    cleanup();
}

bool ShaderProgram::loadFromFiles(const QString &vertexShaderFile, const QString &fragmentShaderFile)
{
    QString vertexSource = readShaderFile(vertexShaderFile);
    QString fragmentSource = readShaderFile(fragmentShaderFile);
    
    if (vertexSource.isEmpty() || fragmentSource.isEmpty()) {
        m_lastError = "无法读取着色器文件";
        return false;
    }
    
    return loadFromSource(vertexSource, fragmentSource);
}

bool ShaderProgram::loadFromSource(const QString &vertexSource, const QString &fragmentSource)
{
    cleanup();
    
    // 创建着色器程序
    m_programId = glCreateProgram();
    if (m_programId == 0) {
        m_lastError = "创建着色器程序失败";
        return false;
    }
    
    // 创建顶点着色器
    m_vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    if (m_vertexShaderId == 0) {
        m_lastError = "创建顶点着色器失败";
        cleanup();
        return false;
    }
    
    // 创建片元着色器
    m_fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
    if (m_fragmentShaderId == 0) {
        m_lastError = "创建片元着色器失败";
        cleanup();
        return false;
    }
    
    // 编译着色器
    if (!compileShader(m_vertexShaderId, vertexSource)) {
        cleanup();
        return false;
    }
    
    if (!compileShader(m_fragmentShaderId, fragmentSource)) {
        cleanup();
        return false;
    }
    
    // 附加着色器到程序
    glAttachShader(m_programId, m_vertexShaderId);
    glAttachShader(m_programId, m_fragmentShaderId);
    
    // 链接程序
    if (!linkProgram()) {
        cleanup();
        return false;
    }
    
    m_linked = true;
    qDebug() << "着色器程序编译链接成功，ID:" << m_programId;
    return true;
}

bool ShaderProgram::compileShader(GLuint shader, const QString &source)
{
    QByteArray sourceBytes = source.toUtf8();
    const char* sourcePtr = sourceBytes.constData();
    
    glShaderSource(shader, 1, &sourcePtr, nullptr);
    glCompileShader(shader);
    
    GLint compiled = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
    
    if (!compiled) {
        QString shaderType = (shader == m_vertexShaderId) ? "顶点着色器" : "片元着色器";
        checkShaderCompileStatus(shader, shaderType);
        return false;
    }
    
    return true;
}

bool ShaderProgram::linkProgram()
{
    glLinkProgram(m_programId);
    
    GLint linked = 0;
    glGetProgramiv(m_programId, GL_LINK_STATUS, &linked);
    
    if (!linked) {
        checkProgramLinkStatus();
        return false;
    }
    
    return true;
}

GLint ShaderProgram::attributeLocation(const QString &name) const
{
    if (!m_linked) return -1;
    return glGetAttribLocation(m_programId, name.toUtf8().constData());
}

GLint ShaderProgram::uniformLocation(const QString &name) const
{
    if (!m_linked) return -1;
    return glGetUniformLocation(m_programId, name.toUtf8().constData());
}

void ShaderProgram::cleanup()
{
    if (m_vertexShaderId) {
        glDeleteShader(m_vertexShaderId);
        m_vertexShaderId = 0;
    }
    
    if (m_fragmentShaderId) {
        glDeleteShader(m_fragmentShaderId);
        m_fragmentShaderId = 0;
    }
    
    if (m_programId) {
        glDeleteProgram(m_programId);
        m_programId = 0;
    }
    
    m_linked = false;
}

QString ShaderProgram::readShaderFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "无法打开着色器文件:" << filename;
        return QString();
    }
    
    QTextStream stream(&file);
    return stream.readAll();
}

void ShaderProgram::checkShaderCompileStatus(GLuint shader, const QString &shaderType)
{
    GLint logLength = 0;
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLength);
    
    if (logLength > 0) {
        QByteArray log(logLength, '\0');
        glGetShaderInfoLog(shader, logLength, nullptr, log.data());
        m_lastError = QString("%1编译失败:\n%2").arg(shaderType, QString::fromUtf8(log));
        qDebug() << m_lastError;
    } else {
        m_lastError = QString("%1编译失败，无详细信息").arg(shaderType);
        qDebug() << m_lastError;
    }
}

void ShaderProgram::checkProgramLinkStatus()
{
    GLint logLength = 0;
    glGetProgramiv(m_programId, GL_INFO_LOG_LENGTH, &logLength);
    
    if (logLength > 0) {
        QByteArray log(logLength, '\0');
        glGetProgramInfoLog(m_programId, logLength, nullptr, log.data());
        m_lastError = QString("着色器程序链接失败:\n%1").arg(QString::fromUtf8(log));
        qDebug() << m_lastError;
    } else {
        m_lastError = "着色器程序链接失败，无详细信息";
        qDebug() << m_lastError;
    }
}
