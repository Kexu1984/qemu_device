# 3D OBJ 渲染器 - Qt 5.6.3 + OpenGL ES 2.0

## 项目概述

这是一个专为嵌入式ARM平台（Mali-400 GPU）设计的3D OBJ模型渲染器，使用Qt 5.6.3和OpenGL ES 2.0开发。

## 功能特性

- **OBJ文件解析**：支持顶点位置(v)、法线(vn)、纹理坐标(vt)、面(f)
- **智能顶点去重**：使用哈希表优化，减少内存使用
- **四边形自动三角化**：扇形三角化算法
- **索引渲染**：使用glDrawElements + GL_UNSIGNED_SHORT
- **基础光照**：Lambert漫反射 + 环境光
- **纹理映射**：支持漫反射贴图
- **相机交互**：轨道旋转、平移、缩放
- **性能优化**：针对Mali-400 GPU优化

## 系统要求

- Qt 5.6.3
- OpenGL ES 2.0
- ARM Mali-400 GPU（目标平台）
- Linux嵌入式系统

## 编译和运行

### 桌面开发环境（调试）

```bash
# 配置项目
qmake render_3d_obj.pro

# 编译
make

# 运行
./render_3d_obj
```

### 嵌入式ARM目标平台

```bash
# 使用交叉编译工具链
export PATH=/path/to/arm-toolchain/bin:$PATH
export PKG_CONFIG_PATH=/path/to/target/lib/pkgconfig

# 配置Qt环境
export QTDIR=/path/to/qt5.6.3-arm
export PATH=$QTDIR/bin:$PATH

# 配置并编译
qmake render_3d_obj.pro CONFIG+=embedded
make

# 部署到目标板
scp render_3d_obj root@target_ip:/home/root/
scp -r assets/ root@target_ip:/home/root/

# 在目标板运行
export QT_QPA_PLATFORM=eglfs
export QT_QPA_EGLFS_INTEGRATION=eglfs_mali
./render_3d_obj
```

## 项目结构

```
render_3d_obj/
├── render_3d_obj.pro      # qmake项目文件
├── main.cpp               # 主程序入口
├── GLView.h/.cpp          # OpenGL渲染视图
├── ObjLoader.h/.cpp       # OBJ文件解析器
├── Camera.h/.cpp          # 轨道相机控制
├── ShaderProgram.h/.cpp   # 着色器管理
├── Texture.h/.cpp         # 纹理加载
├── mesh.glsl.vert         # 顶点着色器
├── mesh.glsl.frag         # 片元着色器
├── shaders.qrc            # 着色器资源文件
├── assets/                # 资源文件夹
│   ├── model.obj          # 示例OBJ模型
│   └── diffuse.jpg/png    # 漫反射纹理（可选）
└── README.md              # 本文档
```

## 控制方式

- **鼠标左键拖拽**：轨道旋转
- **鼠标右键拖拽**：平移视角
- **鼠标滚轮**：缩放
- **R键**：重置相机
- **W键**：线框模式开关（注：ES2不支持glPolygonMode）

## 文件格式支持

### OBJ文件格式

支持的OBJ指令：
- `v x y z` - 顶点位置
- `vn x y z` - 顶点法线
- `vt u v` - 纹理坐标
- `f v1/vt1/vn1 v2/vt2/vn2 v3/vt3/vn3` - 面定义

### 纹理文件

支持的纹理格式：
- JPG/JPEG
- PNG
- BMP
- 其他Qt支持的图片格式

## 性能优化特性

### Mali-400 GPU优化

1. **索引绘制**：使用16位索引减少内存带宽
2. **交错顶点格式**：position+normal+texcoord，提高缓存命中率
3. **精度优化**：片元着色器使用mediump精度
4. **纹理优化**：
   - 支持mipmap（2的幂尺寸）
   - 线性过滤
   - 自动非2的幂处理

### 内存优化

1. **顶点去重**：哈希表去除重复顶点
2. **紧凑数据结构**：最小化内存占用
3. **智能缓冲**：一次上传，多次使用

## 错误处理

程序包含完善的错误处理：

1. **文件加载错误**：自动回退到默认几何体
2. **着色器编译错误**：详细错误日志输出
3. **OpenGL错误**：每个关键操作后检查
4. **纹理加载错误**：自动创建白色默认纹理

## 扩展功能（可选）

如需添加更多功能，可考虑：

1. **材质系统**：解析MTL文件，支持Ka、Kd等参数
2. **多光源**：点光源、聚光灯支持
3. **阴影映射**：简单阴影实现
4. **法线贴图**：增强细节表现
5. **后处理**：简单的后处理效果

## 调试信息

程序运行时会输出详细的调试信息：

- OpenGL版本和驱动信息
- 模型加载统计
- 性能指标（FPS）
- 错误信息

## 故障排除

### 常见问题

1. **黑屏或崩溃**
   - 检查OpenGL ES 2.0支持
   - 确认正确的EGL配置
   - 查看控制台错误信息

2. **纹理显示异常**
   - 确认纹理文件存在
   - 检查文件格式支持
   - 验证UV坐标范围

3. **性能问题**
   - 减少模型复杂度
   - 优化纹理分辨率
   - 使用更简单的着色器

### 环境变量

```bash
# EGLFS平台配置
export QT_QPA_PLATFORM=eglfs
export QT_QPA_EGLFS_INTEGRATION=eglfs_mali

# 调试选项
export QT_LOGGING_RULES="qt.qpa.eglfs.debug=true"
export MESA_DEBUG=1

# GPU驱动调试
export MALI_DEBUG=1
```

## 技术细节

### 坐标系统

- **右手坐标系**：Y轴向上，Z轴向外
- **相机默认**：看向-Z方向
- **纹理坐标**：左下角为(0,0)，自动处理Y轴翻转

### 着色器约定

**顶点着色器属性**：
```glsl
attribute vec3 a_position;  // 位置 (location未固定，ES2动态查询)
attribute vec3 a_normal;    // 法线
attribute vec2 a_texcoord;  // 纹理坐标
```

**Uniform变量**：
```glsl
uniform mat4 u_mvp;         // 模型-视图-投影矩阵
uniform mat4 u_model;       // 模型矩阵
uniform vec3 u_lightDir;    // 光照方向
uniform sampler2D u_diffuse; // 漫反射纹理
```

### 数据格式

**顶点结构**（32字节，8字节对齐）：
```cpp
struct Vertex {
    QVector3D position;  // 12 bytes
    QVector3D normal;    // 12 bytes  
    QVector2D texcoord;  // 8 bytes
};
```

## 许可证

本项目仅用于学习和研究目的。请遵循Qt和相关开源库的许可证条款。

## 作者

GitHub Copilot - 3D渲染专家助手
