#ifndef SHADERPROGRAM_H
#define SHADERPROGRAM_H

#include <QObject>
#include <QOpenGLFunctions_ES2>
#include <QString>

class ShaderProgram : public QObject, protected QOpenGLFunctions_ES2
{
    Q_OBJECT

public:
    explicit ShaderProgram(QObject *parent = nullptr);
    ~ShaderProgram();

    // 加载着色器
    bool loadFromFiles(const QString &vertexShaderFile, const QString &fragmentShaderFile);
    bool loadFromSource(const QString &vertexSource, const QString &fragmentSource);
    
    // 编译和链接
    bool compileShader(GLuint shader, const QString &source);
    bool linkProgram();
    
    // 获取位置
    GLint attributeLocation(const QString &name) const;
    GLint uniformLocation(const QString &name) const;
    
    // 状态查询
    bool isLinked() const { return m_linked; }
    GLuint programId() const { return m_programId; }
    
    // 错误信息
    QString getLastError() const { return m_lastError; }

private:
    void cleanup();
    QString readShaderFile(const QString &filename);
    void checkShaderCompileStatus(GLuint shader, const QString &shaderType);
    void checkProgramLinkStatus();
    
    GLuint m_programId;
    GLuint m_vertexShaderId;
    GLuint m_fragmentShaderId;
    bool m_linked;
    QString m_lastError;
};

#endif // SHADERPROGRAM_H
