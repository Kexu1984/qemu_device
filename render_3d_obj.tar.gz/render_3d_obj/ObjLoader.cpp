#include "ObjLoader.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QDir>
#include <QStringList>
#include <cmath>

ObjLoader::ObjLoader(QObject *parent)
    : QObject(parent)
{
    clear();
}

bool ObjLoader::loadFromFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "无法打开OBJ文件:" << filename;
        return false;
    }
    
    clear();
    
    QTextStream stream(&file);
    QString line;
    int lineNumber = 0;
    
    qDebug() << "开始解析OBJ文件:" << filename;
    
    while (stream.readLineInto(&line)) {
        lineNumber++;
        if (!parseLine(line.trimmed())) {
            qDebug() << "解析错误在第" << lineNumber << "行:" << line;
        }
    }
    
    file.close();
    
    qDebug() << "OBJ解析完成:";
    qDebug() << "  位置:" << m_positions.size();
    qDebug() << "  法线:" << m_normals.size();
    qDebug() << "  纹理坐标:" << m_texcoords.size();
    qDebug() << "  面:" << m_faces.size();
    
    // 如果没有法线，生成法线
    if (m_normals.isEmpty()) {
        qDebug() << "生成面法线...";
        generateNormals();
    }
    
    // 优化顶点数据
    optimizeVertices();
    
    // 计算边界
    calculateBounds();
    
    qDebug() << "优化后 - 顶点:" << m_vertices.size() << "索引:" << m_indices.size();
    
    return !m_vertices.isEmpty() && !m_indices.isEmpty();
}

void ObjLoader::createDefaultCube()
{
    clear();
    
    // 立方体顶点位置
    QVector<QVector3D> positions = {
        // 前面
        {-1, -1,  1}, { 1, -1,  1}, { 1,  1,  1}, {-1,  1,  1},
        // 后面
        {-1, -1, -1}, {-1,  1, -1}, { 1,  1, -1}, { 1, -1, -1},
        // 左面
        {-1, -1, -1}, {-1, -1,  1}, {-1,  1,  1}, {-1,  1, -1},
        // 右面
        { 1, -1,  1}, { 1, -1, -1}, { 1,  1, -1}, { 1,  1,  1},
        // 下面
        {-1, -1, -1}, { 1, -1, -1}, { 1, -1,  1}, {-1, -1,  1},
        // 上面
        {-1,  1,  1}, { 1,  1,  1}, { 1,  1, -1}, {-1,  1, -1}
    };
    
    // 立方体法线
    QVector<QVector3D> normals = {
        // 前面
        {0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1},
        // 后面
        {0, 0, -1}, {0, 0, -1}, {0, 0, -1}, {0, 0, -1},
        // 左面
        {-1, 0, 0}, {-1, 0, 0}, {-1, 0, 0}, {-1, 0, 0},
        // 右面
        {1, 0, 0}, {1, 0, 0}, {1, 0, 0}, {1, 0, 0},
        // 下面
        {0, -1, 0}, {0, -1, 0}, {0, -1, 0}, {0, -1, 0},
        // 上面
        {0, 1, 0}, {0, 1, 0}, {0, 1, 0}, {0, 1, 0}
    };
    
    // 立方体纹理坐标
    QVector<QVector2D> texcoords = {
        // 前面
        {0, 0}, {1, 0}, {1, 1}, {0, 1},
        // 后面
        {1, 0}, {1, 1}, {0, 1}, {0, 0},
        // 左面
        {0, 0}, {1, 0}, {1, 1}, {0, 1},
        // 右面
        {0, 0}, {1, 0}, {1, 1}, {0, 1},
        // 下面
        {0, 1}, {1, 1}, {1, 0}, {0, 0},
        // 上面
        {0, 0}, {1, 0}, {1, 1}, {0, 1}
    };
    
    // 索引（每个面两个三角形）
    QVector<unsigned short> indices = {
        // 前面
        0, 1, 2,  2, 3, 0,
        // 后面
        4, 5, 6,  6, 7, 4,
        // 左面
        8, 9, 10,  10, 11, 8,
        // 右面
        12, 13, 14,  14, 15, 12,
        // 下面
        16, 17, 18,  18, 19, 16,
        // 上面
        20, 21, 22,  22, 23, 20
    };
    
    // 构建最终顶点数据
    m_vertices.clear();
    m_indices.clear();
    
    for (int i = 0; i < positions.size(); i++) {
        Vertex vertex;
        vertex.position = positions[i];
        vertex.normal = normals[i];
        vertex.texcoord = texcoords[i];
        m_vertices.append(vertex);
    }
    
    m_indices = indices;
    
    // 计算边界
    calculateBounds();
    
    qDebug() << "默认立方体创建完成 - 顶点:" << m_vertices.size() << "索引:" << m_indices.size();
}

void ObjLoader::getBounds(QVector3D &minBounds, QVector3D &maxBounds) const
{
    minBounds = m_minBounds;
    maxBounds = m_maxBounds;
}

void ObjLoader::clear()
{
    m_positions.clear();
    m_normals.clear();
    m_texcoords.clear();
    m_faces.clear();
    m_vertices.clear();
    m_indices.clear();
    m_vertexMap.clear();
    
    m_minBounds = QVector3D(1e6, 1e6, 1e6);
    m_maxBounds = QVector3D(-1e6, -1e6, -1e6);
}

bool ObjLoader::parseLine(const QString &line)
{
    if (line.isEmpty() || line.startsWith('#')) {
        return true; // 注释行或空行
    }
    
    QStringList tokens = line.split(' ', QString::SkipEmptyParts);
    if (tokens.isEmpty()) {
        return true;
    }
    
    const QString &type = tokens[0];
    
    if (type == "v" && tokens.size() >= 4) {
        // 顶点位置
        QVector3D position(tokens[1].toFloat(), tokens[2].toFloat(), tokens[3].toFloat());
        m_positions.append(position);
        return true;
    } else if (type == "vn" && tokens.size() >= 4) {
        // 顶点法线
        QVector3D normal(tokens[1].toFloat(), tokens[2].toFloat(), tokens[3].toFloat());
        m_normals.append(normal.normalized());
        return true;
    } else if (type == "vt" && tokens.size() >= 3) {
        // 纹理坐标
        float u = tokens[1].toFloat();
        float v = tokens[2].toFloat();
        // V轴翻转处理（可选）
        v = 1.0f - v;
        m_texcoords.append(QVector2D(u, v));
        return true;
    } else if (type == "f" && tokens.size() >= 4) {
        // 面
        processFace(tokens);
        return true;
    }
    
    return true; // 忽略不支持的类型
}

void ObjLoader::processFace(const QStringList &tokens)
{
    QVector<FaceVertex> faceVertices;
    
    for (int i = 1; i < tokens.size(); i++) {
        FaceVertex fv = parseFaceVertex(tokens[i]);
        if (fv.positionIndex >= 0) {
            faceVertices.append(fv);
        }
    }
    
    if (faceVertices.size() >= 3) {
        // 三角化（扇形三角化）
        triangulate(faceVertices);
    }
}

ObjLoader::FaceVertex ObjLoader::parseFaceVertex(const QString &vertexStr)
{
    QStringList indices = vertexStr.split('/');
    FaceVertex fv;
    
    if (indices.size() >= 1 && !indices[0].isEmpty()) {
        fv.positionIndex = indices[0].toInt() - 1; // OBJ索引从1开始
    }
    
    if (indices.size() >= 2 && !indices[1].isEmpty()) {
        fv.texcoordIndex = indices[1].toInt() - 1;
    }
    
    if (indices.size() >= 3 && !indices[2].isEmpty()) {
        fv.normalIndex = indices[2].toInt() - 1;
    }
    
    return fv;
}

void ObjLoader::triangulate(const QVector<FaceVertex> &faceVertices)
{
    if (faceVertices.size() < 3) return;
    
    if (faceVertices.size() == 3) {
        // 已经是三角形
        QVector<FaceVertex> triangle = { faceVertices[0], faceVertices[1], faceVertices[2] };
        m_faces.append(triangle);
    } else {
        // 多边形，使用扇形三角化
        for (int i = 1; i < faceVertices.size() - 1; i++) {
            QVector<FaceVertex> triangle = { faceVertices[0], faceVertices[i], faceVertices[i + 1] };
            m_faces.append(triangle);
        }
    }
}

void ObjLoader::optimizeVertices()
{
    m_vertices.clear();
    m_indices.clear();
    m_vertexMap.clear();
    
    for (const auto &face : m_faces) {
        for (const auto &fv : face) {
            unsigned short index;
            
            if (m_vertexMap.contains(fv)) {
                // 重复顶点，使用已有索引
                index = m_vertexMap[fv];
            } else {
                // 新顶点，创建并添加
                Vertex vertex;
                
                // 位置
                if (fv.positionIndex >= 0 && fv.positionIndex < m_positions.size()) {
                    vertex.position = m_positions[fv.positionIndex];
                }
                
                // 法线
                if (fv.normalIndex >= 0 && fv.normalIndex < m_normals.size()) {
                    vertex.normal = m_normals[fv.normalIndex];
                } else {
                    vertex.normal = QVector3D(0, 0, 1); // 默认法线
                }
                
                // 纹理坐标
                if (fv.texcoordIndex >= 0 && fv.texcoordIndex < m_texcoords.size()) {
                    vertex.texcoord = m_texcoords[fv.texcoordIndex];
                } else {
                    vertex.texcoord = QVector2D(0, 0); // 默认UV
                }
                
                index = m_vertices.size();
                m_vertices.append(vertex);
                m_vertexMap[fv] = index;
            }
            
            m_indices.append(index);
        }
    }
    
    qDebug() << "顶点优化完成，去重率:" 
             << (1.0f - float(m_vertices.size()) / float(m_indices.size())) * 100.0f << "%";
}

void ObjLoader::generateNormals()
{
    // 为每个面生成法线
    m_normals.clear();
    m_normals.resize(m_positions.size());
    
    // 计算每个面的法线并累加到顶点
    for (const auto &face : m_faces) {
        if (face.size() >= 3) {
            const FaceVertex &v0 = face[0];
            const FaceVertex &v1 = face[1];
            const FaceVertex &v2 = face[2];
            
            if (v0.positionIndex >= 0 && v0.positionIndex < m_positions.size() &&
                v1.positionIndex >= 0 && v1.positionIndex < m_positions.size() &&
                v2.positionIndex >= 0 && v2.positionIndex < m_positions.size()) {
                
                QVector3D p0 = m_positions[v0.positionIndex];
                QVector3D p1 = m_positions[v1.positionIndex];
                QVector3D p2 = m_positions[v2.positionIndex];
                
                QVector3D normal = QVector3D::crossProduct(p1 - p0, p2 - p0).normalized();
                
                for (const auto &fv : face) {
                    if (fv.positionIndex >= 0 && fv.positionIndex < m_normals.size()) {
                        m_normals[fv.positionIndex] += normal;
                    }
                }
            }
        }
    }
    
    // 标准化所有法线
    for (auto &normal : m_normals) {
        normal = normal.normalized();
    }
    
    qDebug() << "生成了" << m_normals.size() << "个顶点法线";
}

void ObjLoader::calculateBounds()
{
    if (m_vertices.isEmpty()) return;
    
    m_minBounds = m_vertices[0].position;
    m_maxBounds = m_vertices[0].position;
    
    for (const auto &vertex : m_vertices) {
        const QVector3D &pos = vertex.position;
        
        m_minBounds.setX(qMin(m_minBounds.x(), pos.x()));
        m_minBounds.setY(qMin(m_minBounds.y(), pos.y()));
        m_minBounds.setZ(qMin(m_minBounds.z(), pos.z()));
        
        m_maxBounds.setX(qMax(m_maxBounds.x(), pos.x()));
        m_maxBounds.setY(qMax(m_maxBounds.y(), pos.y()));
        m_maxBounds.setZ(qMax(m_maxBounds.z(), pos.z()));
    }
}
