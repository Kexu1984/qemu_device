#include "Camera.h"
#include <QtMath>

Camera::Camera(QObject *parent)
    : QObject(parent)
    , m_target(0, 0, 0)
    , m_up(0, 1, 0)
    , m_distance(5.0f)
    , m_azimuth(0.0f)
    , m_elevation(0.0f)
    , m_fov(45.0f)
    , m_aspectRatio(1.0f)
    , m_nearPlane(0.1f)
    , m_farPlane(100.0f)
    , m_viewDirty(true)
    , m_projectionDirty(true)
{
    updatePosition();
}

QMatrix4x4 Camera::getViewMatrix() const
{
    if (m_viewDirty) {
        m_viewMatrix.setToIdentity();
        m_viewMatrix.lookAt(m_position, m_target, m_up);
        m_viewDirty = false;
    }
    return m_viewMatrix;
}

QMatrix4x4 Camera::getProjectionMatrix() const
{
    if (m_projectionDirty) {
        updateProjection();
    }
    return m_projectionMatrix;
}

void Camera::orbit(float deltaX, float deltaY)
{
    // 轨道旋转，围绕目标点旋转
    m_azimuth += deltaX * 0.01f;   // 水平旋转
    m_elevation += deltaY * 0.01f; // 垂直旋转
    
    // 限制垂直角度防止翻转
    m_elevation = qBound(-M_PI * 0.49f, m_elevation, M_PI * 0.49f);
    
    // 标准化水平角度
    while (m_azimuth > M_PI) m_azimuth -= 2 * M_PI;
    while (m_azimuth < -M_PI) m_azimuth += 2 * M_PI;
    
    updatePosition();
    m_viewDirty = true;
}

void Camera::pan(float deltaX, float deltaY)
{
    // 获取相机坐标系的右向量和上向量
    QVector3D forward = (m_target - m_position).normalized();
    QVector3D right = QVector3D::crossProduct(forward, m_up).normalized();
    QVector3D up = QVector3D::crossProduct(right, forward).normalized();
    
    // 根据相机距离调整平移速度
    float panScale = m_distance * 0.001f;
    
    // 计算平移向量
    QVector3D panVector = right * deltaX * panScale + up * deltaY * panScale;
    
    // 同时移动相机位置和目标点
    m_target += panVector;
    m_position += panVector;
    
    m_viewDirty = true;
}

void Camera::zoom(float delta)
{
    // 缩放通过改变距离实现
    m_distance *= (1.0f - delta);
    
    // 限制最小和最大距离
    m_distance = qBound(0.1f, m_distance, 100.0f);
    
    updatePosition();
    m_viewDirty = true;
}

void Camera::setAspectRatio(float aspectRatio)
{
    if (m_aspectRatio != aspectRatio) {
        m_aspectRatio = aspectRatio;
        m_projectionDirty = true;
    }
}

void Camera::setFov(float fov)
{
    if (m_fov != fov) {
        m_fov = fov;
        m_projectionDirty = true;
    }
}

void Camera::setNearFar(float nearPlane, float farPlane)
{
    if (m_nearPlane != nearPlane || m_farPlane != farPlane) {
        m_nearPlane = nearPlane;
        m_farPlane = farPlane;
        m_projectionDirty = true;
    }
}

void Camera::resetToPosition(const QVector3D &position, const QVector3D &target)
{
    m_target = target;
    m_position = position;
    
    // 计算相应的球坐标
    QVector3D direction = m_position - m_target;
    m_distance = direction.length();
    
    if (m_distance > 0.001f) {
        direction.normalize();
        m_elevation = asin(direction.y());
        m_azimuth = atan2(direction.x(), direction.z());
    } else {
        m_distance = 1.0f;
        m_elevation = 0.0f;
        m_azimuth = 0.0f;
        updatePosition();
    }
    
    m_viewDirty = true;
}

void Camera::updatePosition()
{
    // 从球坐标计算笛卡尔坐标
    float cosElevation = cos(m_elevation);
    float x = m_distance * cosElevation * sin(m_azimuth);
    float y = m_distance * sin(m_elevation);
    float z = m_distance * cosElevation * cos(m_azimuth);
    
    m_position = m_target + QVector3D(x, y, z);
}

void Camera::updateProjection() const
{
    m_projectionMatrix.setToIdentity();
    m_projectionMatrix.perspective(m_fov, m_aspectRatio, m_nearPlane, m_farPlane);
    m_projectionDirty = false;
}
